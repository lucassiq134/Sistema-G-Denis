<?php
require 'conexao.php';

if (!isset($_GET['id'])) {
    die("ID não informado!");
}

$id = intval($_GET['id']);


$sql = "SELECT * FROM disciplinas WHERE id=$id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Disciplina não encontrada!");
}
$disciplina = $result->fetch_assoc();


$sqlProf = "SELECT id, nome FROM professores ORDER BY nome ASC";
$professores = $conn->query($sqlProf);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Disciplina</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
        h1 { text-align: center; }
        form { width: 400px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        label { display: block; margin-top: 10px; font-weight: bold; }
        input, select { width: 95%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px; }
        input[type="submit"] { background: #4e73df; color: white; border: none; cursor: pointer; margin-top: 15px; }
        input[type="submit"]:hover { background: #2e59d9; }
        a.voltar { display: block; margin: 20px auto; width: 200px; padding: 10px; text-align: center; background: #4e73df; color: white; text-decoration: none; border-radius: 5px; }
        a.voltar:hover { background: #2e59d9; }
    </style>
</head>
<body>

<h1>Editar Disciplina</h1>

<form method="POST" action="atualizar_disciplina.php">
    <input type="hidden" name="id" value="<?= $disciplina['id'] ?>">

    <label>Nome:</label>
    <input type="text" name="nome" value="<?= htmlspecialchars($disciplina['nome']) ?>" required>

    <label>Código:</label>
    <input type="text" name="codigo" value="<?= htmlspecialchars($disciplina['codigo']) ?>" required>

    <label>Carga Horária:</label>
    <input type="text" name="carga_horaria" value="<?= htmlspecialchars($disciplina['carga_horaria']) ?>" required>

    <label>Professor:</label>
    <select name="professor" required>
        <option value="">-- Selecione --</option>
        <?php while($p = $professores->fetch_assoc()): ?>
            <option value="<?= htmlspecialchars($p['nome']) ?>"
                <?= ($disciplina['professor'] == $p['nome']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($p['nome']) ?>
            </option>
        <?php endwhile; ?>
    </select>

    <input type="submit" value="Salvar Alterações">
</form>

<a href="listar_disciplinas.php" class="voltar">⬅ Voltar à Lista</a>

</body>
</html>
