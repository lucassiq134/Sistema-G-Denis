<?php
session_start();


if (!isset($_SESSION['id']) || $_SESSION['tipo'] !== 'professor') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel do Professor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(120deg, #00c6ff, #0072ff);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 0px 15px rgba(0,0,0,0.2);
            width: 400px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
        }
        a {
            display: block;
            margin: 12px 0;
            padding: 12px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: 0.3s;
        }
        a:hover {
            background: #0056b3;
        }
        .logout {
            background: red;
        }
        .logout:hover {
            background: darkred;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Bem-vindo, Professor <?php echo htmlspecialchars($_SESSION['nome']); ?> 👨‍🏫</h2>

          <a href="registrar_presenca2.php">✏️ Registrar Presença</a>
        <a href="lancar-notas-faltas.php">📘 Lançar Notas</a>
        <a href="emitir_relatorios.php">📊 Emitir Relatórios</a>
        <a href="visualizar_boletim_matricula.html">📄 Visualizar Boletins</a>
        <a href="listar_presencas.php">✏️ Presenças Cadastradas</a></li>
        <a href="listar_notas_faltas.php">📝 Notas Lançadas</a>
        
        <a href="login.php" class="logout">🚪 Sair</a>
    </div>
</body>
</html>
