<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);


include 'conexao.php';


$nome       = $_POST['nome'];
$matricula  = $_POST['matricula'];
$nascimento = $_POST['nascimento'];
$email      = $_POST['email'];
$turma_id   = $_POST['turma_id'];


$sql = "INSERT INTO alunos (nome, matricula, nascimento, email, turma_id) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Erro na preparação da query: " . $conn->error);
}

$stmt->bind_param("ssssi", $nome, $matricula, $nascimento, $email, $turma_id);


if ($stmt->execute()) {
    echo "
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Cadastro Concluído</title>
        <style>
            body {
                background-color: #f0f2f5;
                font-family: Arial, sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }
            .mensagem {
                background-color: #ffffff;
                padding: 20px 40px;
                border-radius: 10px;
                box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
                text-align: center;
                animation: fadeIn 0.5s ease-in-out;
            }
            .mensagem h1 {
                color: #28a745;
                margin-bottom: 10px;
            }
            .mensagem p {
                color: #555;
                font-size: 14px;
            }
            @keyframes fadeIn {
                from { opacity: 0; transform: scale(0.9); }
                to { opacity: 1; transform: scale(1); }
            }
        </style>
        <meta http-equiv='refresh' content='3;url=cadastro-alunos.php'>
    </head>
    <body>
        <div class='mensagem'>
            <h1>✅ Aluno cadastrado com sucesso!</h1>
            <p>Você será redirecionado em 3 segundos...</p>
        </div>
    </body>
    </html>
    ";
} else {
    echo "Erro: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
