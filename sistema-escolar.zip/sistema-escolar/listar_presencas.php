<?php
include("conexao.php");


$data = isset($_GET['data']) ? $_GET['data'] : "";
$turma_id = isset($_GET['turma_id']) ? $_GET['turma_id'] : "";
$disciplina_id = isset($_GET['disciplina_id']) ? $_GET['disciplina_id'] : "";


$sql = "SELECT p.data, a.nome AS aluno, t.serie, d.nome AS disciplina, p.presente
        FROM presencas p
        INNER JOIN alunos a ON a.id = p.aluno_id
        INNER JOIN turmas t ON t.id = p.turma_id
        INNER JOIN disciplinas d ON d.id = p.disciplina_id
        WHERE 1=1";

if (!empty($data)) {
    $sql .= " AND p.data = '$data'";
}
if (!empty($turma_id)) {
    $sql .= " AND t.id = '$turma_id'";
}
if (!empty($disciplina_id)) {
    $sql .= " AND d.id = '$disciplina_id'";
}

$sql .= " ORDER BY p.data DESC, t.serie ASC, a.nome ASC";

$res = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Presenças Registradas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            max-width: 1100px;
            margin: 30px auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        form {
            text-align: center;
            margin-bottom: 20px;
        }
        select, input[type="date"], button {
            padding: 6px 10px;
            margin: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        button {
            background: #007BFF;
            color: white;
            cursor: pointer;
            border: none;
        }
        button:hover {
            background: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            border: 1px solid #e0e0e0;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .presente {
            color: green;
            font-weight: bold;
        }
        .ausente {
            color: red;
            font-weight: bold;
        }
        .sair-btn {
            display: block;
            width: 120px;
            margin: 20px auto 0 auto;
            text-align: center;
            padding: 10px;
            background: #007BFF;
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }
        .sair-btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Presenças Registradas</h2>

   
        <form method="GET">
            <label>Data:</label>
            <input type="date" name="data" value="<?php echo $data; ?>">

            <label>Turma:</label>
            <select name="turma_id">
                <option value="">Todas</option>
                <?php
                $turmas = mysqli_query($conn, "SELECT id, serie FROM turmas ORDER BY serie");
                while ($t = mysqli_fetch_assoc($turmas)) {
                    $sel = ($turma_id == $t['id']) ? "selected" : "";
                    echo "<option value='{$t['id']}' $sel>{$t['serie']}</option>";
                }
                ?>
            </select>

            <label>Disciplina:</label>
            <select name="disciplina_id">
                <option value="">Todas</option>
                <?php
                $disciplinas = mysqli_query($conn, "SELECT id, nome FROM disciplinas ORDER BY nome");
                while ($d = mysqli_fetch_assoc($disciplinas)) {
                    $sel = ($disciplina_id == $d['id']) ? "selected" : "";
                    echo "<option value='{$d['id']}' $sel>{$d['nome']}</option>";
                }
                ?>
            </select>

            <button type="submit">Filtrar</button>
        </form>

       
        <table>
            <tr>
                <th>Data</th>
                <th>Turma</th>
                <th>Disciplina</th>
                <th>Aluno</th>
                <th>Status</th>
            </tr>
            <?php
            if (mysqli_num_rows($res) > 0) {
                while ($row = mysqli_fetch_assoc($res)) {
                    $status = $row['presente'] ? "<span class='presente'>Presente</span>" : "<span class='ausente'>Ausente</span>";
                    echo "<tr>
                            <td>{$row['data']}</td>
                            <td>{$row['serie']}</td>
                            <td>{$row['disciplina']}</td>
                            <td>{$row['aluno']}</td>
                            <td>$status</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>Nenhuma presença encontrada.</td></tr>";
            }
            ?>
        </table>

  
<a href="javascript:history.back()" class="sair-btn">Sair</a>

    </div>
</body>
</html>
