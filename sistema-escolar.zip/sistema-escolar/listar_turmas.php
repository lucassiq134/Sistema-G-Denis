<?php 
require_once "conexao.php";


if (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'
) {
    header('Content-Type: application/json; charset=utf-8');

    $sql = "SELECT id, serie, ano_letivo FROM turmas ORDER BY serie ASC, ano_letivo ASC";
    $result = $conn->query($sql);

    $turmas = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $status = ($row['ano_letivo'] <= 2025) ? "Ativa" : "Inativa";

            $turmas[] = [
                "id" => $row["id"],
                "serie" => $row["serie"],
                "ano_letivo" => $row["ano_letivo"],
                "status" => $status
            ];
        }
    }
    echo json_encode($turmas);
    exit;
}


$sql = "SELECT id, nome, serie, ano_letivo FROM turmas ORDER BY serie ASC, ano_letivo ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Turmas Cadastradas</title>
<style>
    body { font-family: Arial, sans-serif; background: #f8f9fa; padding: 20px; }
    table { width: 80%; margin: auto; border-collapse: collapse; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
    th { background-color: #4e73df; color: white; }
    .ativa { color: green; font-weight: bold; }
    .inativa { color: red; font-weight: bold; }
    a { display: inline-block; margin-top: 20px; text-decoration: none; background: #4e73df; color: white; padding: 10px; border-radius: 5px; }
    a:hover { background: #2e59d9; }
</style>
</head>
<body>

<h2 style="text-align:center;">Turmas Cadastradas</h2>

<table>
<tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Série</th>
    <th>Ano Letivo</th>
    <th>Status</th>
</tr>
<?php
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $status = ($row['ano_letivo'] <= 2025) ? "<span class='ativa'>Ativa</span>" : "<span class='inativa'>Inativa</span>";
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['nome']}</td>
                <td>{$row['serie']}</td>
                <td>{$row['ano_letivo']}</td>
                <td>{$status}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>Nenhuma turma cadastrada</td></tr>";
}
?>
</table>

<div style="text-align:center;">
    <a href="painel-admin.html">← Voltar ao Painel</a>
</div>

</body>
</html>
