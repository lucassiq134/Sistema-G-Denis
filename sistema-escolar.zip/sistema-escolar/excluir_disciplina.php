<?php
include "conexao.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); 

    
    $sql = "DELETE FROM disciplinas WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>
                alert('Disciplina excluída com sucesso!');
                window.location.href='listar_disciplinas.php';
              </script>";
    } else {
        echo "<script>
                alert('Erro ao excluir disciplina.');
                window.location.href='listar_disciplinas.php';
              </script>";
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: listar_disciplinas.php");
    exit;
}
?>
