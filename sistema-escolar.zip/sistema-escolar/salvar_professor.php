<?php
include 'conexao.php';


$nome            = $_POST['nome'];
$materia         = $_POST['materia'];
$email           = $_POST['email'];
$data_nascimento = $_POST['data_nascimento'];


$sql_prof = "INSERT INTO professores (nome, materia, email, data_nascimento) 
             VALUES ('$nome', '$materia', '$email', '$data_nascimento')";

if (mysqli_query($conn, $sql_prof)) {

 
    $senha = date("dmY", strtotime($data_nascimento));

    $sql_user = "INSERT INTO usuarios (nome, email, senha, tipo) 
                 VALUES ('$nome', '$email', '$senha', 'professor')";

    if (mysqli_query($conn, $sql_user)) {
        echo "<script>alert('Professor e usuário criados com sucesso!'); 
              window.location.href='painel-admin.html';</script>";
    } else {
        echo "Erro ao criar usuário: " . mysqli_error($conn);
    }

} else {
    echo "Erro ao cadastrar professor: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
