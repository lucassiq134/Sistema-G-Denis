<?php
include 'conexao.php';

if (isset($_GET['matricula'])) {
    $matricula = $_GET['matricula'];

    $sql = "
        SELECT 
            a.nome AS aluno,
            a.matricula,
            d.nome AS disciplina,
            nf.bimestre,
            nf.nota,
            nf.faltas
        FROM notas_faltas nf
        INNER JOIN alunos a ON nf.aluno_id = a.id
        INNER JOIN disciplinas d ON nf.disciplina_id = d.id
        WHERE a.matricula = '$matricula'
        ORDER BY d.nome, nf.bimestre
    ";

    $result = $conn->query($sql);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Boletim do Aluno</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h4>Boletim do Aluno</h4>
        </div>
        <div class="card-body">
            <?php if (isset($result) && $result->num_rows > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Aluno</th>
                            <th>Matrícula</th>
                            <th>Disciplina</th>
                            <th>Bimestre</th>
                            <th>Nota</th>
                            <th>Faltas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['aluno'] ?></td>
                                <td><?= $row['matricula'] ?></td>
                                <td><?= $row['disciplina'] ?></td>
                                <td><?= $row['bimestre'] ?></td>
                                <td><?= $row['nota'] ?></td>
                                <td><?= $row['faltas'] ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-warning">
                    Nenhum registro encontrado para a matrícula: <strong><?= htmlspecialchars($matricula) ?></strong>
                </div>
            <?php endif; ?>
            <a href="visualizar_boletim_matricula.html" class="btn btn-secondary mt-3">Voltar</a>
        </div>
    </div>
</div>

</body>
</html>
