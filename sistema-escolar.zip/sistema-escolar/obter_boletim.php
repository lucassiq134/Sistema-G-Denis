<?php
include 'conexao.php';

$id = intval($_GET['id']);

$sql = "SELECT d.nome AS disciplina, nf.nota, nf.faltas
        FROM notas_faltas nf
        JOIN disciplinas d ON nf.disciplina_id = d.id
        WHERE nf.aluno_id = $id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h3>Boletim do Aluno</h3>";
    echo "<table>
            <tr>
                <th>Disciplina</th>
                <th>Nota</th>
                <th>Faltas</th>
            </tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['disciplina']}</td>
                <td>{$row['nota']}</td>
                <td>{$row['faltas']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhuma nota encontrada para este aluno.</p>";
}

$conn->close();
?>
