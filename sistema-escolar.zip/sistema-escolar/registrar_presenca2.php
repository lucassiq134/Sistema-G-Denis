<?php
include("conexao.php");

$turma_id = isset($_POST['turma_id']) ? $_POST['turma_id'] : null;
$disciplina_id = isset($_POST['disciplina_id']) ? $_POST['disciplina_id'] : null;
$data = isset($_POST['data']) ? $_POST['data'] : date("Y-m-d");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['salvar'])) {
    $professor_id = 1; 

    if (!empty($_POST['presenca'])) {
        foreach ($_POST['presenca'] as $aluno_id => $valor) {
            $presente = ($valor == '1') ? 1 : 0;

            $sql = "INSERT INTO presencas (aluno_id, turma_id, disciplina_id, professor_id, data, presente) 
                    VALUES ('$aluno_id', '$turma_id', '$disciplina_id', '$professor_id', '$data', '$presente')";
            mysqli_query($conn, $sql);
        }
    }

    echo "<script>alert('Presenças salvas com sucesso!');</script>";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Registrar Presença</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            max-width: 900px;
            margin: 30px auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 25px;
        }
        label {
            font-weight: bold;
            margin-right: 10px;
        }
        select, input[type="date"] {
            padding: 6px 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin: 5px 0 15px 0;
            width: 200px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            border: 1px solid #e0e0e0;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: #fff;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .btn {
            background: #007BFF;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 10px 18px;
            margin: 8px 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
            transition: 0.3s;
        }
        .btn:hover {
            background: #0056b3;
        }
        .actions {
            text-align: center;
            margin-top: 20px;
        }
    </style>
    <script>
        function selecionarTodos() {
            document.querySelectorAll('input[type=checkbox]').forEach(c => c.checked = true);
        }
        function desselecionarTodos() {
            document.querySelectorAll('input[type=checkbox]').forEach(c => c.checked = false);
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Registrar Presença</h2>
        <form method="POST">
            <label>Data:</label>
            <input type="date" name="data" value="<?php echo $data; ?>" required><br>

            <label>Série:</label>
            <select name="turma_id" required onchange="this.form.submit()">
                <option value="">Selecione a série</option>
                <?php
                $res = mysqli_query($conn, "
                    SELECT id, serie 
                    FROM turmas 
                    ORDER BY 
                        CAST(SUBSTRING_INDEX(serie, 'º', 1) AS UNSIGNED), 
                        SUBSTRING(serie, -1) ASC
                ");
                while ($row = mysqli_fetch_assoc($res)) {
                    $selected = ($turma_id == $row['id']) ? "selected" : "";
                    echo "<option value='{$row['id']}' $selected>{$row['serie']}</option>";
                }
                ?>
            </select><br>

            <label>Disciplina:</label>
            <select name="disciplina_id" required>
                <option value="">Selecione a disciplina</option>
                <?php
                $res = mysqli_query($conn, "SELECT * FROM disciplinas");
                while ($row = mysqli_fetch_assoc($res)) {
                    $selected = ($disciplina_id == $row['id']) ? "selected" : "";
                    echo "<option value='{$row['id']}' $selected>{$row['nome']}</option>";
                }
                ?>
            </select><br>

            <div class="actions">
                <?php if ($turma_id): ?>
                    <button type="button" class="btn" onclick="selecionarTodos()">Selecionar Todos</button>
                    <button type="button" class="btn" onclick="desselecionarTodos()">Limpar Seleção</button>
                    <button type="submit" class="btn" name="salvar">Salvar Presença</button>
                <?php endif; ?>
              
                <a class="btn" href="area_professor.php">⬅ Voltar para o Painel</a>
            </div>

            <?php if ($turma_id): ?>
            <table>
                <tr>
                    <th>Aluno</th>
                    <th>Presente</th>
                </tr>
                <?php
                $res = mysqli_query($conn, "SELECT * FROM alunos WHERE turma_id = '$turma_id'");
                while ($aluno = mysqli_fetch_assoc($res)) {
                    echo "<tr>
                            <td>{$aluno['nome']}</td>
                            <td><input type='checkbox' name='presenca[{$aluno['id']}]' value='1'></td>
                          </tr>";
                }
                ?>
            </table>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>
