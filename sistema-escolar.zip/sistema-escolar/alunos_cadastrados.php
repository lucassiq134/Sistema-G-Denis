<?php
include 'conexao.php';


$serie = isset($_GET['serie']) ? $_GET['serie'] : '';


$sql = "SELECT a.id, a.nome, a.matricula, a.nascimento, 
               IFNULL(t.serie, 'Não informado') AS turma, 
               a.email
        FROM alunos a
        LEFT JOIN turmas t ON a.turma_id = t.id";

if (!empty($serie)) {
    $sql .= " WHERE t.serie = '" . $conn->real_escape_string($serie) . "'";
}

$result = $conn->query($sql);


$turmas = $conn->query("SELECT DISTINCT serie FROM turmas ORDER BY serie ASC");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alunos Cadastrados</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffffff;
            text-align: center;
        }
        table {
            width: 80%;
            margin: 30px auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #000;
        }
        th {
            background-color: #f2f2f2;
        }
        h1 {
            margin-top: 20px;
        }
        .btn-voltar, .btn-limpar {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn-voltar:hover, .btn-limpar:hover {
            background-color: #444;
        }
        form {
            margin-top: 20px;
        }
        select {
            padding: 5px;
        }
        button {
            padding: 5px 10px;
            background: #000;
            color: #fff;
            border: none;
            border-radius: 5px;
        }
        button:hover {
            background: #444;
        }
    </style>
</head>
<body>
    <h1>📋 Alunos Cadastrados</h1>

 
    <form method="get" action="">
        <label for="serie">Selecione a Série:</label>
        <select name="serie" id="serie">
            <option value="">-- Todas --</option>
            <?php while ($turma = $turmas->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($turma['serie']) ?>" 
                    <?= ($serie == $turma['serie']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($turma['serie']) ?>
                </option>
            <?php endwhile; ?>
        </select>
        <button type="submit">Filtrar</button>
       
    </form>


    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Matrícula</th>
            <th>Data de Nascimento</th>
            <th>Turma (Série)</th>
            <th>Email</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['nome']) ?></td>
                <td><?= htmlspecialchars($row['matricula']) ?></td>
                <td><?= htmlspecialchars($row['nascimento']) ?></td>
                <td><?= htmlspecialchars($row['turma']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6">Nenhum aluno encontrado.</td></tr>
        <?php endif; ?>
    </table>

    <a href="painel-admin.html" class="btn-voltar">⬅ Voltar ao Painel</a>
</body>
</html>
