<?php
include 'conexao.php';


$sql = "SELECT id, serie, nome FROM turmas ORDER BY serie ASC, nome ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Alunos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .voltar {
            display: block;
            margin-top: 15px;
            padding: 10px;
            background: #4e73df;
            color: white !important;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            width: 100%;
        }
        .voltar:hover {
            background: #2e59d9;
            color: white !important;
        }
    </style>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card p-4 shadow-lg mx-auto" style="max-width: 400px;">
        <h4 class="text-center mb-4">Cadastro de Alunos</h4>
        
        <form action="processa_cadastro_aluno.php" method="POST">
            <div class="mb-3">
                <label class="form-label">Nome completo:</label>
                <input type="text" name="nome" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Matrícula:</label>
                <input type="text" name="matricula" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Data de nascimento:</label>
                <input type="date" name="data_nascimento" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Turma:</label>
                <select name="turma" class="form-select" required>
                    <option value="">Selecione</option>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <option value="<?php echo $row['id']; ?>">
                            <?php echo $row['serie'] . " - " . $row['nome']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">E-mail:</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Cadastrar</button>
        </form>

        <a href="javascript:history.back()" class="voltar">← Voltar</a>
    </div>
</div>

</body>
</html>
