<?php
include 'conexao.php';

$turma_id = $_GET['turma'] ?? '';

if (!$turma_id) {
    die("Turma não selecionada.");
}


$sql_turma = "SELECT serie, ano_letivo FROM turmas WHERE id = ?";
$stmt = $conn->prepare($sql_turma);
$stmt->bind_param("i", $turma_id);
$stmt->execute();
$result_turma = $stmt->get_result();

if ($result_turma->num_rows == 0) {
    die("Turma não encontrada.");
}
$turma = $result_turma->fetch_assoc();


$sql_alunos = "SELECT id, nome, matricula FROM alunos WHERE turma_id = ?";
$stmt_alunos = $conn->prepare($sql_alunos);
$stmt_alunos->bind_param("i", $turma_id);
$stmt_alunos->execute();
$result_alunos = $stmt_alunos->get_result();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Boletim da Turma</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h2 { margin-bottom: 5px; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
        th { background-color: #f4f4f4; }
    </style>
</head>
<body>

<h2>Boletim - Turma <?= htmlspecialchars($turma['serie']) ?> (<?= htmlspecialchars($turma['ano_letivo']) ?>)</h2>

<?php while ($aluno = $result_alunos->fetch_assoc()): ?>
    <h3>Aluno: <?= htmlspecialchars($aluno['nome']) ?> - Matrícula: <?= htmlspecialchars($aluno['matricula']) ?></h3>
    <table>
        <tr>
            <th>Disciplina</th>
            <th>Bimestre</th>
            <th>Nota</th>
            <th>Faltas</th>
        </tr>
        <?php
        $sql_notas = "SELECT d.nome AS disciplina, n.bimestre, n.nota, n.faltas 
                      FROM notas_faltas n
                      JOIN disciplinas d ON n.disciplina_id = d.id
                      WHERE n.aluno_id = ?";
        $stmt_notas = $conn->prepare($sql_notas);
        $stmt_notas->bind_param("i", $aluno['id']);
        $stmt_notas->execute();
        $result_notas = $stmt_notas->get_result();

        while ($nota = $result_notas->fetch_assoc()):
        ?>
            <tr>
                <td><?= htmlspecialchars($nota['disciplina']) ?></td>
                <td><?= htmlspecialchars($nota['bimestre']) ?></td>
                <td><?= htmlspecialchars($nota['nota']) ?></td>
                <td><?= htmlspecialchars($nota['faltas']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php endwhile; ?>

</body>
</html>
