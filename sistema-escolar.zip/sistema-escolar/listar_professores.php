<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'conexao.php'; 

$sql = "SELECT * FROM professores";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professores Cadastrados</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        h1 { text-align: center; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        th { background-color: #007bff; color: white; }
        a { display: inline-block; margin-top: 15px; text-decoration: none; padding: 10px 20px; background-color: #007bff; color: white; border-radius: 6px; }
        a:hover { background-color: #0056b3; }
        .center { text-align: center; margin-top: 20px; }
    </style>
</head>
<body>
    <h1>👨‍🏫 Professores Cadastrados</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Disciplina</th>
            <th>Email</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['nome']}</td>
                        <td>{$row['materia']}</td>
                        <td>{$row['email']}</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Nenhum professor cadastrado</td></tr>";
        }
        ?>
    </table>

    <div class="center">
        <a href="painel-admin.html">⬅ Voltar ao Painel</a>
    </div>
</body>
</html>
<?php $conn->close(); ?>
