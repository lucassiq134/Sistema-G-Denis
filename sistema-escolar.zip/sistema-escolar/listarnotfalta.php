<?php
session_start();
include 'conexao.php';


if (!isset($_SESSION['professor_id'])) {
    header("Location: login.php");
    exit;
}


$professor_id = $_SESSION['professor_id'];


$sql = "SELECT d.id, d.nome 
        FROM disciplinas d
        INNER JOIN professor_disciplinas pd ON d.id = pd.disciplina_id
        WHERE pd.professor_id = :professor_id";

$stmt = $pdo->prepare($sql);
$stmt->bindParam(':professor_id', $professor_id, PDO::PARAM_INT);
$stmt->execute();
$disciplinas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lançar Notas e Faltas</title>
</head>
<body>
    <h2>Selecione a disciplina</h2>

    <?php if (count($disciplinas) > 0): ?>
        <form method="post" action="processar-notas.php">
            <label for="disciplina">Disciplina:</label>
            <select name="disciplina_id" id="disciplina" required>
                <?php foreach($disciplinas as $disc): ?>
                    <option value="<?= $disc['id'] ?>"><?= $disc['nome'] ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Continuar</button>
        </form>
    <?php else: ?>
        <p>⚠ Nenhuma disciplina foi vinculada ao seu usuário.</p>
    <?php endif; ?>
</body>
</html>
