<?php
require 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $nome = $_POST['nome'];
    $codigo = $_POST['codigo'];
    $carga_horaria = $_POST['carga_horaria'];
    $professor = $_POST['professor'];

    $sql = "UPDATE disciplinas 
            SET nome=?, codigo=?, carga_horaria=?, professor=? 
            WHERE id=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $nome, $codigo, $carga_horaria, $professor, $id);

    if ($stmt->execute()) {
        header("Location: listar_disciplinas.php?msg=sucesso");
        exit;
    } else {
        echo "Erro ao atualizar: " . $conn->error;
    }
} else {
    echo "Requisição inválida.";
}
?>
