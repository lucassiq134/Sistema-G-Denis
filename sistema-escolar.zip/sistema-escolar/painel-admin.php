<?php
session_start();
if (!isset($_SESSION['usuario_tipo'])) {
    header("Location: index.html");
    exit;
}
$tipo = $_SESSION['usuario_tipo'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel Administrativo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #222;
            color: #fff;
            padding: 20px;
            height: 100vh;
        }
        .sidebar h2 {
            color: #fff;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 10px 0;
        }
        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
        }
        .sidebar ul li a:hover {
            text-decoration: underline;
        }
        .content {
            flex: 1;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin</h2>
        <ul>
            <?php if ($tipo == 'admin'): ?>
                <li><a href="cadastro-alunos.php">Cadastro de Alunos</a></li>
                <li><a href="cadastro-professores.php">Cadastro de Professores</a></li>
                <li><a href="salvar_turma.php">Cadastro de Turmas</a></li>
                <li><a href="salvar_disciplina.php">Cadastro de Disciplinas</a></li>
                <li><a href="lancar-notas-faltas.php">Lançar Notas e Faltas</a></li>
                <li><a href="emitir_relatorios.php">Emitir Relatórios</a></li>
                <li><a href="visualizar_boletin_matricula.html">Visualizar Boletins</a></li>
                <li><a href="alunos_cadastrados.php">Alunos Cadastrados</a></li>
                <li><a href="listar_professores.php">Professores Cadastrados</a></li>
                <li><a href="listar_turmas.php">Turmas Cadastradas</a></li>
                <li><a href="listar_disciplinas.php">Disciplinas Cadastradas</a></li>
                <li><a href="listar_notas_faltas.php">Notas e Faltas Lançadas</a></li>
            <?php elseif ($tipo == 'professor'): ?>
                <li><a href="lancar-notas-faltas.php">Lançar Notas e Faltas</a></li>
                <li><a href="emitir_relatorios.php">Emitir Relatórios</a></li>
                <li><a href="visualizar_boletin_matricula.html">Visualizar Boletins</a></li>
            <?php elseif ($tipo == 'aluno'): ?>
                <li><a href="visualizar_boletin_matricula.html">Visualizar Boletins</a></li>
            <?php endif; ?>
            <li><a href="logout.php">Sair</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Painel Administrativo</h1>
        <p>Bem-vindo ao sistema de gestão escolar. Selecione uma das opções no menu para começar.</p>
    </div>
</body>
</html>
