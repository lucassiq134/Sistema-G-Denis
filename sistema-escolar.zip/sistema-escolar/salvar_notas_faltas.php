<?php
require_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $aluno_id = $_POST["aluno_id"];
    $disciplina_id = $_POST["disciplina_id"];
    $bimestre = $_POST["bimestre"];
    $nota = $_POST["nota"];


    $sql = "INSERT INTO notas_faltas (aluno_id, disciplina_id, bimestre, nota, faltas) 
            VALUES ('$aluno_id', '$disciplina_id', '$bimestre', '$nota', 0)";

    if ($conn->query($sql) === TRUE) {
        echo "
        <html>
        <head>
            <meta http-equiv='refresh' content='2;url=listar_notas_faltas.php'>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background: #f4f4f4;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                }
                .msg {
                    background: #d4edda;
                    color: #155724;
                    padding: 20px 30px;
                    border: 1px solid #c3e6cb;
                    border-radius: 8px;
                    text-align: center;
                    font-size: 18px;
                    box-shadow: 0px 2px 8px rgba(0,0,0,0.1);
                }
            </style>
        </head>
        <body>
            <div class='msg'>
                ✅ Nota lançada com sucesso! <br>
                Você será redirecionado...
            </div>
        </body>
        </html>
        ";
    } else {
        echo "
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background: #f4f4f4;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                }
                .msg {
                    background: #f8d7da;
                    color: #721c24;
                    padding: 20px 30px;
                    border: 1px solid #f5c6cb;
                    border-radius: 8px;
                    text-align: center;
                    font-size: 18px;
                    box-shadow: 0px 2px 8px rgba(0,0,0,0.1);
                }
            </style>
        </head>
        <body>
            <div class='msg'>
                ❌ Erro ao lançar nota: " . $conn->error . "
            </div>
        </body>
        </html>
        ";
    }
}
?>
