<?php
header('Content-Type: application/json');
include 'conexao.php'; 


$sql = "SELECT id, nome FROM alunos ORDER BY nome";
$result = $conn->query($sql);

$alunos = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $alunos[] = $row;
    }
}


echo json_encode($alunos);

$conn->close();
?>
