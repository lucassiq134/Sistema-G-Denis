<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Professores</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            max-width: 500px;
            margin: auto;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .btn-voltar {
            background-color: #007bff;
            margin-top: 20px;
            display: block;
            text-align: center;
            padding: 10px;
            color: white;
            border-radius: 4px;
            text-decoration: none;
            max-width: 200px;
            margin-left: auto;
            margin-right: auto;
        }
        .btn-voltar:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h2>Cadastro de Professores</h2>

    <?php
   
    include("conexao.php");

    
    $sql = "SELECT id, nome FROM disciplinas";
    $result = $conn->query($sql);
    ?>

    <form action="salvar_professor.php" method="POST">
        <label for="nome">Nome do Professor:</label>
        <input type="text" id="nome" name="nome" required>

        <label for="materia">Disciplina:</label>
        <select id="materia" name="materia" required>
            <option value="">Selecione</option>
            <?php while($row = $result->fetch_assoc()) { ?>
                <option value="<?php echo $row['nome']; ?>">
                    <?php echo $row['nome']; ?>
                </option>
            <?php } ?>
        </select>

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required>

        <!-- Campo adicionado -->
        <label for="data_nascimento">Data de Nascimento:</label>
        <input type="date" id="data_nascimento" name="data_nascimento" required>

        <button type="submit">Cadastrar</button>
    </form>

    <a class="btn-voltar" href="painel-admin.html">⬅ Voltar para o Painel</a>

</body>
</html>
