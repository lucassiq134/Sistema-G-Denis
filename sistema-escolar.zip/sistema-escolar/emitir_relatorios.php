<?php
include 'conexao.php';


$sql = "SELECT id, serie, ano_letivo FROM turmas ORDER BY serie ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Emitir Relatórios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 350px;
        }
        select, button {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #4CAF50; 
            color: white;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background-color: #45a049; 
        }
        .voltar {
            display: block;
            margin: 20px 0 0 0; 
            padding: 8px; 
            background: #4CAF50;
            color: white !important;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            width: 100%;
            transition: background 0.3s;
        }
        .voltar:hover {
            background: #45a049;
            color: white !important;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>📊 Emitir Relatórios</h2>
    <form action="visualizar_boletins.php" method="GET">
        <label for="tipo_relatorio">Tipo de Relatório:</label>
        <select name="tipo_relatorio" id="tipo_relatorio" required>
            <option value="">Selecione</option>
            <option value="boletim">Boletim de Alunos</option>
        </select>

        <label for="turma">Turma:</label>
        <select name="turma" id="turma" required>
            <option value="">Selecione</option>
            <?php while($row = $result->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>">
                    <?= htmlspecialchars($row['serie']) ?> - <?= htmlspecialchars($row['ano_letivo']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <button type="submit">Visualizar Relatório</button>
    </form>

  
    <a href="javascript:history.back()" class="voltar">← Voltar</a>
</div>
</body>
</html>
