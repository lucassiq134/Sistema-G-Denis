<?php 
require_once "conexao.php"; 
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lançar Notas</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
        h2 { text-align: center; }
        form {
            background: white;
            padding: 20px;
            max-width: 500px;
            margin: auto;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        label { font-weight: bold; display: block; margin-top: 10px; }
        select, input {
            width: 100%; padding: 8px; margin-top: 5px;
            border: 1px solid #ccc; border-radius: 4px;
        }
        button {
            margin-top: 15px; padding: 10px;
            background-color: #4e73df; color: white;
            border: none; border-radius: 4px; cursor: pointer;
        }
        button:hover { background-color: #2e59d9; }
        .voltar {
            display: block;
            margin: 20px auto 0;
            padding: 10px;
            background: #4e73df;
            color: white;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            width: 150px;
        }
        .voltar:hover { 
            background: #2e59d9;
        }
    </style>
</head>
<body>

<h2>Lançar Notas</h2>

<form action="salvar_notas_faltas.php" method="POST">
   
    <label>Aluno:</label>
    <select name="aluno_id" required>
        <option value="">Selecione</option>
        <?php
        $result = $conn->query("SELECT id, nome FROM alunos ORDER BY nome");
        while ($aluno = $result->fetch_assoc()) {
            echo "<option value='{$aluno['id']}'>{$aluno['nome']}</option>";
        }
        ?>
    </select>

   
    <label>Disciplina:</label>
    <select name="disciplina_id" required>
        <option value="">Selecione</option>
        <?php
        $result = $conn->query("SELECT id, nome FROM disciplinas ORDER BY nome");
        while ($disc = $result->fetch_assoc()) {
            echo "<option value='{$disc['id']}'>{$disc['nome']}</option>";
        }
        ?>
    </select>

    
    <label>Bimestre:</label>
    <select name="bimestre" required>
        <option value="1º Bimestre">1º Bimestre</option>
        <option value="2º Bimestre">2º Bimestre</option>
        <option value="3º Bimestre">3º Bimestre</option>
        <option value="4º Bimestre">4º Bimestre</option>
    </select>


    <label>Nota:</label>
    <input type="number" name="nota" step="0.01" min="0" max="10" required>

    <button type="submit">Lançar</button>
</form>


<a href="javascript:history.back()" class="voltar">← Voltar</a>

</body>
</html>
