<?php
include "conexao.php";

$nome      = $_POST['nome'];
$codigo    = $_POST['codigo'];
$carga     = $_POST['carga'];
$professor = $_POST['professor'];

$sql = "INSERT INTO disciplinas (nome, codigo, carga_horaria, professor) 
        VALUES ('$nome', '$codigo', '$carga', '$professor')";

if ($conn->query($sql) === TRUE) {
    echo "
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Sucesso</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f0f2f5;
                text-align: center;
                padding: 100px;
            }
            .msg {
                background: #dff0d8;
                color: #3c763d;
                border: 1px solid #d6e9c6;
                padding: 20px;
                border-radius: 8px;
                font-size: 20px;
                display: inline-block;
                box-shadow: 0px 2px 6px rgba(0,0,0,0.1);
            }
        </style>
        <script>
            setTimeout(function(){
                window.location.href = 'listar_disciplinas.php';
            }, 2000); // Redireciona em 2 segundos
        </script>
    </head>
    <body>
        <div class='msg'>
            ✅ Disciplina cadastrada com sucesso!<br>
            Você será redirecionado...
        </div>
    </body>
    </html>
    ";
} else {
    echo "Erro: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
