<?php
include 'conexao.php';

if (!isset($_GET['turma']) || empty($_GET['turma'])) {
    die("Turma não informada.");
}

$turma_id = $_GET['turma'];


$stmt = $conn->prepare("SELECT serie, turma FROM turmas WHERE id = ?");
$stmt->bind_param("i", $turma_id);
$stmt->execute();
$result = $stmt->get_result();
$turma = $result->fetch_assoc();

if (!$turma) {
    die("Turma não encontrada.");
}


$stmt = $conn->prepare("SELECT id, nome, matricula FROM alunos WHERE turma_id = ?");
$stmt->bind_param("i", $turma_id);
$stmt->execute();
$alunos = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Boletim da Turma</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h2 { text-align: center; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 30px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
        th { background: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Boletim da Turma <?php echo htmlspecialchars($turma['serie']." ".$turma['turma']); ?></h2>

    <?php while ($aluno = $alunos->fetch_assoc()): ?>
        <h3><?php echo htmlspecialchars($aluno['nome']); ?> (Matrícula: <?php echo htmlspecialchars($aluno['matricula']); ?>)</h3>
        <table>
            <tr>
                <th>Disciplina</th>
                <th>Bimestre</th>
                <th>Nota</th>
                <th>Faltas</th>
            </tr>
            <?php
            $stmtNotas = $conn->prepare("SELECT d.nome AS disciplina, n.bimestre, n.nota, n.faltas
                                         FROM notas_faltas n
                                         JOIN disciplinas d ON d.id = n.disciplina_id
                                         WHERE n.aluno_id = ?");
            $stmtNotas->bind_param("i", $aluno['id']);
            $stmtNotas->execute();
            $notas = $stmtNotas->get_result();

            if ($notas->num_rows > 0):
                while ($row = $notas->fetch_assoc()):
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['disciplina']); ?></td>
                    <td><?php echo htmlspecialchars($row['bimestre']); ?></td>
                    <td><?php echo htmlspecialchars($row['nota']); ?></td>
                    <td><?php echo htmlspecialchars($row['faltas']); ?></td>
                </tr>
            <?php endwhile; else: ?>
                <tr><td colspan="4">Nenhuma nota encontrada.</td></tr>
            <?php endif; ?>
        </table>
    <?php endwhile; ?>

    <a href="emitir_relatorios.php">← Voltar</a>
</body>
</html>
