<?php
$servername = "sql210.infinityfree.com";
$username   = "if0_39760088";
$password   = "lu020220";
$dbname     = "if0_39760088_sistema_escolar";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Forçar UTF-8
$conn->set_charset("utf8");
?>
