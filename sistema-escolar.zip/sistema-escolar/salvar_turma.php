<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome       = $_POST['nome'] ?? '';
    $serie      = $_POST['serie'] ?? '';
    $ano_letivo = $_POST['ano_letivo'] ?? '';

    if ($nome && $serie && $ano_letivo) {
     
        require 'conexao.php';

      
        $stmt = $conn->prepare("INSERT INTO turmas (nome, serie, ano_letivo) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nome, $serie, $ano_letivo);

        if ($stmt->execute()) {
            echo "<script>
                    alert('✅ Turma cadastrada com sucesso!');
                    window.location.href = 'listar_turmas.php';
                  </script>";
        } else {
            echo "Erro no banco: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "<script>
                alert('⚠ Preencha todos os campos!');
                window.history.back();
              </script>";
    }
} else {
    header("Location: cadastro-turmas.html");
    exit;
}
?>
