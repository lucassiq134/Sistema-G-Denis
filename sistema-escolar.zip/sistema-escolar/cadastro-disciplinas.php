<?php
include "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = trim($_POST['nome']);
    $codigo = trim($_POST['codigo']);
    $carga_horaria = (int) $_POST['carga_horaria'];
    $professor = !empty($_POST['professor']) ? $_POST['professor'] : NULL;

    if (!empty($nome) && !empty($codigo) && !empty($carga_horaria)) {
        $professor_id = NULL;

      
        if ($professor !== NULL) {
            $stmt = $conn->prepare("SELECT id FROM professores WHERE nome = ?");
            $stmt->bind_param("s", $professor);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $professor_id = (int) $row['id'];
            }
            $stmt->close();
        }

       
        if ($professor_id !== NULL) {
            $sql = "INSERT INTO disciplinas (nome, codigo, carga_horaria, professor_id) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssii", $nome, $codigo, $carga_horaria, $professor_id);
        } else {
            $sql = "INSERT INTO disciplinas (nome, codigo, carga_horaria) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $nome, $codigo, $carga_horaria);
        }

        if ($stmt->execute()) {
            echo "<script>alert('Disciplina cadastrada com sucesso!'); window.location.href='listar_disciplinas.php';</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar disciplina: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Preencha todos os campos obrigatórios!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Disciplinas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
            max-width: 500px;
            margin: auto;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #4e73df;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #2e59d9;
        }
        .btn-voltar {
            background-color: #007bff;
            margin-top: 20px;
            display: block;
            text-align: center;
            padding: 10px;
            color: white;
            border-radius: 4px;
            text-decoration: none;
            max-width: 200px;
            margin-left: auto;
            margin-right: auto;
        }
        .btn-voltar:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h2>Cadastro de Disciplinas</h2>

    <form method="POST">
        <label>Nome da Disciplina:</label>
        <input type="text" name="nome" required>

        <label>Código:</label>
        <input type="text" name="codigo" required>

        <label>Carga Horária (em horas):</label>
        <input type="number" name="carga_horaria" required>

        <label>Professor Responsável:</label>
        <select name="professor">
            <option value="">Nenhum</option>
            <?php
                $sql = "SELECT nome FROM professores";
                $result = $conn->query($sql);
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='".$row['nome']."'>".$row['nome']."</option>";
                    }
                } else {
                    echo "<option value=''>Nenhum professor cadastrado</option>";
                }
            ?>
        </select>

        <button type="submit">Cadastrar</button>
    </form>

    <a class="btn-voltar" href="painel-admin.html">⬅ Voltar para o Painel</a>

</body>
</html>
