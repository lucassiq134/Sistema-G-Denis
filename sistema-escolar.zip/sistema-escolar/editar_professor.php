<?php
require 'conexao.php';

if (!isset($_GET['id'])) {
    die("ID não informado!");
}

$id = intval($_GET['id']);
$sql = "SELECT * FROM professores WHERE id=$id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Professor não encontrado!");
}
$professor = $result->fetch_assoc();


$sqlDisciplinas = "SELECT id, nome FROM disciplinas ORDER BY nome ASC";
$disciplinas = $conn->query($sqlDisciplinas);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Professor</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
        h1 { text-align: center; }
        form { width: 400px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        label { display: block; margin-top: 10px; font-weight: bold; }
        input, select { width: 95%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px; }
        input[type="submit"] { background: #4e73df; color: white; border: none; cursor: pointer; margin-top: 15px; }
        input[type="submit"]:hover { background: #2e59d9; }
        a.voltar { display: block; margin: 20px auto; width: 200px; padding: 10px; text-align: center; background: #4e73df; color: white; text-decoration: none; border-radius: 5px; }
        a.voltar:hover { background: #2e59d9; }
    </style>
</head>
<body>

<h1>Editar Professor</h1>

<form method="POST" action="atualizar_professor.php">
    <input type="hidden" name="id" value="<?= $professor['id'] ?>">

    <label>Nome:</label>
    <input type="text" name="nome" value="<?= htmlspecialchars($professor['nome']) ?>" required>

    <label>Disciplina:</label>
    <select name="disciplina" required>
        <option value="">-- Selecione --</option>
        <?php while($d = $disciplinas->fetch_assoc()): ?>
            <option value="<?= htmlspecialchars($d['nome']) ?>"
                <?= ($professor['disciplina'] == $d['nome']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($d['nome']) ?>
            </option>
        <?php endwhile; ?>
    </select>

    <label>Email:</label>
    <input type="email" name="email" value="<?= htmlspecialchars($professor['email']) ?>" required>

    <input type="submit" value="Salvar Alterações">
</form>

<a href="listar_professores.php" class="voltar">⬅ Voltar à Lista</a>

</body>
</html>
