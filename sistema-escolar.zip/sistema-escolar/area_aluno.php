<?php
session_start();


if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}


if (!isset($_SESSION['id']) || $_SESSION['tipo'] !== 'aluno') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Área do Aluno</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(90deg, #7b2ff7, #00c6ff);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0,0,0,0.2);
            text-align: center;
            width: 300px;
        }
        h2 {
            margin-bottom: 20px;
        }
        a {
            display: block;
            padding: 10px;
            margin: 8px 0;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        a:hover {
            background: #0056b3;
        }
        .logout {
            background: #dc3545;
        }
        .logout:hover {
            background: #a71d2a;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Bem-vindo, <?php echo $_SESSION['nome']; ?>!</h2>
        <a href="visualizar_boletim_matricula.html">📄 Visualizar Boletins</a>
        <a class="logout" href="area_aluno.php?logout=true">Sair</a>
    </div>
</body>
</html>
