<?php
require 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $nome = $conn->real_escape_string($_POST['nome']);
    $disciplina = $conn->real_escape_string($_POST['disciplina']);
    $email = $conn->real_escape_string($_POST['email']);

    $sql = "UPDATE professores 
            SET nome='$nome', disciplina='$disciplina', email='$email' 
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: listar_professores.php?msg=editado");
        exit;
    } else {
        echo "Erro ao atualizar: " . $conn->error;
    }
}
$conn->close();
?>
