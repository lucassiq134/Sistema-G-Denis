<?php
require 'conexao.php'; 

$sql = "SELECT * FROM disciplinas ORDER BY nome ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Disciplinas Cadastradas</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
        h1 { text-align: center; }
        table { width: 80%; margin: auto; border-collapse: collapse; background: white; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: left; }
        th { background: #4e73df; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        a.voltar { display: block; margin: 20px auto; width: 200px; padding: 10px; text-align: center; background: #4e73df; color: white; text-decoration: none; border-radius: 5px; }
        a.voltar:hover { background: #2e59d9; }
        .btn-editar { color: #4e73df; text-decoration: none; font-weight: bold; }
        .btn-editar:hover { text-decoration: underline; }
    </style>
</head>
<body>

<h1>Disciplinas Cadastradas</h1>

<?php if ($result && $result->num_rows > 0): ?>
<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Código</th>
        <th>Carga Horária</th>
        <th>Professor</th>
        <th>Ações</th>
    </tr>
    <?php while($d = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $d['id'] ?></td>
        <td><?= htmlspecialchars($d['nome']) ?></td>
        <td><?= htmlspecialchars($d['codigo']) ?></td>
        <td><?= htmlspecialchars($d['carga_horaria']) ?> horas</td>
        <td><?= htmlspecialchars($d['professor']) ?></td>
        <td><a class="btn-editar" href="editar_disciplina.php?id=<?= $d['id'] ?>">Editar</a></td>
    </tr>
    <?php endwhile; ?>
</table>
<?php else: ?>
<p style="text-align: center;">Nenhuma disciplina cadastrada.</p>
<?php endif; ?>

<a href="painel-admin.html" class="voltar">⬅ Voltar ao Painel</a>

</body>
</html>
<?php
$conn->close();
?>
