<?php 
require_once "conexao.php"; 

$sql = "SELECT nf.id, a.nome AS aluno, d.nome AS disciplina, nf.bimestre, nf.nota
        FROM notas_faltas nf
        JOIN alunos a ON nf.aluno_id = a.id
        JOIN disciplinas d ON nf.disciplina_id = d.id
        ORDER BY a.nome, nf.bimestre";

$result = $conn->query($sql);
$dados = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Notas Lançadas</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
        h1 { text-align: center; }
        table { width: 90%; margin: auto; border-collapse: collapse; background: white; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
        th { background: #4e73df; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .btn-voltar {
            display: block;
            margin: 20px auto;
            width: 200px;
            padding: 10px;
            background: #4e73df; 
            color: white;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
        }
        .btn-voltar:hover {
            background: #2e59d9; 
        }
    </style>
</head>
<body>

<h1>Notas Lançadas</h1>

<?php if (count($dados) > 0): ?>
<table>
    <tr>
        <th>Aluno</th>
        <th>Disciplina</th>
        <th>Bimestre</th>
        <th>Nota</th>
    </tr>
    <?php foreach ($dados as $linha): ?>
    <tr>
        <td><?= htmlspecialchars($linha['aluno']) ?></td>
        <td><?= htmlspecialchars($linha['disciplina']) ?></td>
        <td><?= $linha['bimestre'] ?></td>
        <td><?= $linha['nota'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php else: ?>
<p style="text-align:center;">Nenhum lançamento encontrado.</p>
<?php endif; ?>


<a href="javascript:history.back()" class="btn-voltar">← Voltar</a>

</body>
</html>
