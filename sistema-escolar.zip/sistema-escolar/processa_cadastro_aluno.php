<?php
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome        = $_POST['nome'];
    $matricula   = $_POST['matricula'];
    $nascimento  = $_POST['data_nascimento'];
    $turma_id    = $_POST['turma'];
    $email       = $_POST['email'];

    
    $senha = $matricula;

    
    $sql = "INSERT INTO alunos (nome, matricula, nascimento, turma_id, email, senha) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    
    $stmt->bind_param("sssiss", $nome, $matricula, $nascimento, $turma_id, $email, $senha);

    if ($stmt->execute()) {
       
        $sql_user = "INSERT INTO usuarios (nome, email, senha, tipo) 
                     VALUES (?, ?, ?, 'aluno')";
        $stmt_user = $conn->prepare($sql_user);
        $stmt_user->bind_param("sss", $nome, $email, $senha);
        $stmt_user->execute();

       
        echo "
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta http-equiv='refresh' content='3;url=alunos_cadastrados.php'>
            <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
        </head>
        <body class='bg-light d-flex justify-content-center align-items-center' style='height:100vh;'>
            <div class='card shadow p-4 text-center' style='max-width: 500px;'>
                <h4 class='text-success'>✅ Aluno cadastrado com sucesso!</h4>
                <p>🔑 O aluno poderá acessar com:</p>
                <p><b>Email:</b> $email<br>
                <b>Senha:</b> $matricula (sua matrícula)</p>
                <div class='spinner-border text-primary mt-3' role='status'>
                  <span class='visually-hidden'>Carregando...</span>
                </div>
                <p class='mt-2 text-muted'>Você será redirecionado em 3 segundos...</p>
            </div>
        </body>
        </html>
        ";
    } else {
        echo "Erro ao cadastrar aluno: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
